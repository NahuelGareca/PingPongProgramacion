import pygame
import random
import re  # Para usar expresiones regulares y buscar el último número de partida en el archivo
from bola import Bola
from pala_juego import Pala
from registro import registrar_colision

# Inicializar Pygame y ajustar la pantalla a 960 píxeles de ancho y 480 píxeles de alto
pygame.init()
ANCHO_PANTALLA = 960
ALTO_PANTALLA = 480
screen = pygame.display.set_mode((ANCHO_PANTALLA, ALTO_PANTALLA))

# Fuente para el texto
font = pygame.font.Font(None, 36)

# Función para leer el último número de partida del archivo colisiones.txt
def leer_numero_partida():
    try:
        with open('colisiones.txt', 'r') as file:
            contenido = file.readlines()
            num_partida = 1
            for linea in contenido:
                match = re.search(r'Partida: (\d+)', linea)
                if match:
                    num_partida = int(match.group(1))
            return num_partida
    except FileNotFoundError:
        return 1

# Variables globales
puntos_ganar = 20  # Puntos necesarios para ganar
num_partida = leer_numero_partida()  # Iniciar la partida con el último número encontrado

# Función para validar el inicio de sesión
def validar_usuario(usuario, password):
    try:
        with open('usuarios.txt', 'r') as file:
            for linea in file:
                datos = linea.strip().split(":")
                if len(datos) == 2:
                    if datos[0] == usuario and datos[1] == password:
                        return True
        return False
    except FileNotFoundError:
        return False

# Pantalla de inicio de sesión
def mostrar_inicio_sesion():
    usuario = ""
    password = ""
    ingresando_usuario = True  # Si es True, se está ingresando el usuario, si es False, la contraseña
    input_active = False  # Controla si se está ingresando el texto
    error_message = ""

    while True:
        screen.fill((0, 0, 0))
        texto_usuario = font.render("Usuario: " + usuario, True, (255, 255, 255))
        texto_password = font.render("Contraseña: " + "*" * len(password), True, (255, 255, 255))
        screen.blit(texto_usuario, (200, 150))
        screen.blit(texto_password, (200, 250))

        # Mostrar mensaje de error si es necesario
        if error_message:
            texto_error = font.render(error_message, True, (255, 0, 0))
            screen.blit(texto_error, (200, 350))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Enter para cambiar entre usuario/contraseña
                    if ingresando_usuario:
                        ingresando_usuario = False
                    else:
                        if validar_usuario(usuario, password):
                            return  # Inicia el juego si las credenciales son correctas
                        else:
                            error_message = "Usuario o contraseña incorrectos"
                            usuario = ""
                            password = ""
                            ingresando_usuario = True

                elif event.key == pygame.K_BACKSPACE:  # Borrar el último caracter
                    if ingresando_usuario:
                        usuario = usuario[:-1]
                    else:
                        password = password[:-1]

                else:
                    if ingresando_usuario:
                        usuario += event.unicode
                    else:
                        password += event.unicode

# Función para reiniciar el juego
def reiniciar_juego():
    global score1, score2, num_partida
    score1 = 0  # Puntaje del jugador 1
    score2 = 0  # Puntaje del jugador 2
    num_partida += 1  # Incrementar el número de partida
    bola1.reset_position()
    bola2.reset_position()
    bola3.reset_position()
    pala1.reset_position()
    pala2.reset_position()

# Crear jugadores
pala1 = Pala(1, ANCHO_PANTALLA)
pala2 = Pala(2, ANCHO_PANTALLA)

# Crear tres bolas
bola1 = Bola(ANCHO_PANTALLA)
bola2 = Bola(ANCHO_PANTALLA)
bola3 = Bola(ANCHO_PANTALLA)

# Inicializar puntajes
score1 = 0
score2 = 0

# Agrupar sprites
palas = pygame.sprite.Group(pala1, pala2)
bolas = pygame.sprite.Group(bola1, bola2, bola3)

# Control de tiempo
clock = pygame.time.Clock()

def mostrar_menu_inicio():
    screen.fill((0, 0, 0))
    texto_titulo = font.render("PONG MULTIBALL", True, (255, 255, 255))
    texto_iniciar = font.render("1. Iniciar Juego", True, (255, 255, 255))
    texto_reglas = font.render("2. Ver Reglas", True, (255, 255, 255))
    texto_salir = font.render("3. Salir", True, (255, 255, 255))
    screen.blit(texto_titulo, (400, 150))
    screen.blit(texto_iniciar, (400, 250))
    screen.blit(texto_reglas, (400, 300))
    screen.blit(texto_salir, (400, 350))
    pygame.display.flip()
    
    # Esperar hasta que se seleccione una opción en el menú
    esperando = True
    while esperando:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:  # Opción para iniciar juego
                    esperando = False
                elif event.key == pygame.K_2:  # Opción para ver reglas
                    mostrar_reglas()  # Ir a la pantalla de reglas
                elif event.key == pygame.K_3:  # Opción para salir
                    pygame.quit()
                    exit()

def mostrar_reglas():
    screen.fill((0, 0, 0))
    reglas = [
        "REGLAS DEL JUEGO:",
        "1. Usa W y S para mover la pala del Jugador 1.",
        "2. Usa las flechas ARRIBA y ABAJO para mover la pala del Jugador 2.",
        "3. El objetivo es evitar que la pelota salga de tu lado.",
        "4. Si la pelota pasa por el lado de un jugador, el oponente gana un punto.",
        "5. Presiona ESC para pausar o salir del juego."
    ]
    for i, regla in enumerate(reglas):
        texto_regla = font.render(regla, True, (255, 255, 255))
        screen.blit(texto_regla, (50, 100 + i * 40))
    
    texto_continuar = font.render("Presiona cualquier tecla para volver al menú", True, (255, 255, 255))
    screen.blit(texto_continuar, (100, 400))
    pygame.display.flip()
    
    # Esperar a que el usuario presione una tecla para volver al menú
    esperando = True
    while esperando:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                esperando = False
                mostrar_menu_inicio()

def mostrar_barra_superior():
    texto_pausa = font.render("Presiona ESC para pausar el juego", True, (255, 255, 255))
    screen.blit(texto_pausa, (380, 10))

# Función para mostrar quién ganó y preguntar si se desea jugar de nuevo
def mostrar_ganador(ganador):
    screen.fill((0, 0, 0))
    texto_ganador = font.render(f"¡El Jugador {ganador} ganó la partida!", True, (255, 255, 255))
    texto_reiniciar = font.render("¿Deseas volver a jugar? Presiona 'S' para sí o 'N' para no", True, (255, 255, 255))
    screen.blit(texto_ganador, (200, 150))
    screen.blit(texto_reiniciar, (100, 250))
    pygame.display.flip()
    
    esperando_respuesta = True
    while esperando_respuesta:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s:
                    reiniciar_juego()  # Reiniciar juego con nueva partida
                    esperando_respuesta = False
                elif event.key == pygame.K_n:
                    pygame.quit()
                    exit()

# Mostrar la pantalla de inicio de sesión antes del menú
mostrar_inicio_sesion()

# Mostrar el menú inicial
mostrar_menu_inicio()

# Bucle del juego
running = True
paused = False
while running:
    clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                paused = not paused

    if paused:
        mostrar_menu_inicio()
        paused = False

    palas.update()
    bola1.update(pala1, pala2, score1, num_partida)
    bola2.update(pala1, pala2, score1, num_partida)
    bola3.update(pala1, pala2, score1, num_partida)

    for bola in [bola1, bola2, bola3]:
        if bola.rect.left <= 0:  # Jugador 2 anota
            score2 += 1
            bola.reset_position()
            registrar_colision(1, "Perdió", num_partida, bola.rect.topleft)
            bola.incrementar_velocidad(1.1)
        elif bola.rect.right >= ANCHO_PANTALLA:  # Jugador 1 anota
            score1 += 1
            bola.reset_position()
            registrar_colision(2, "Perdió", num_partida, bola.rect.topleft)
            bola.incrementar_velocidad(1.1)

        if pygame.sprite.collide_rect(bola, pala1):
            bola.speed[0] = -bola.speed[0]
            registrar_colision(1, "Pala", num_partida, bola.rect.topleft)
        if pygame.sprite.collide_rect(bola, pala2):
            bola.speed[0] = -bola.speed[0]
            registrar_colision(2, "Pala", num_partida, bola.rect.topleft)

    screen.fill((0, 0, 0))
    palas.draw(screen)
    bolas.draw(screen)

    text1 = font.render(f'Jugador 1: {score1}', True, (255, 255, 255))
    text2 = font.render(f'Jugador 2: {score2}', True, (255, 255, 255))
    screen.blit(text1, (50, 40))
    screen.blit(text2, (ANCHO_PANTALLA - 200, 40))

    mostrar_barra_superior()
    pygame.display.flip()

pygame.quit()
