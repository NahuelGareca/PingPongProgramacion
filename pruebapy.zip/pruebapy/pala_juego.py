import pygame

class Pala(pygame.sprite.Sprite):
    def __init__(self, jugador, ancho_pantalla):
        super().__init__()
        self.image = pygame.Surface((10, 100))
        self.image.fill((255, 255, 255))
        self.rect = self.image.get_rect()
        self.jugador = jugador
        self.ancho_pantalla = ancho_pantalla
        self.reset_position()  # Inicializa la posición al crear la pala

    def update(self):
        keys = pygame.key.get_pressed()
        if self.jugador == 1:
            if keys[pygame.K_w]:
                self.rect.y -= 5
            if keys[pygame.K_s]:
                self.rect.y += 5
        else:
            if keys[pygame.K_UP]:
                self.rect.y -= 5
            if keys[pygame.K_DOWN]:
                self.rect.y += 5

        # Limitar la pala dentro de la pantalla
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > 480:
            self.rect.bottom = 480

    def reset_position(self):
        """Restablece la pala a su posición inicial."""
        if self.jugador == 1:
            self.rect.x = 30  # Jugador 1 a la izquierda
        else:
            self.rect.x = self.ancho_pantalla - 40  # Jugador 2 a la derecha
        self.rect.y = 190  # Posición vertical inicial
