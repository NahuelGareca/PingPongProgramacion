import pygame
import random

class Bola(pygame.sprite.Sprite):
    def __init__(self, ancho_pantalla):
        super().__init__()
        self.ancho_pantalla = ancho_pantalla
        self.image = pygame.Surface((20, 20))
        self.image.fill((255, 255, 255))
        self.rect = self.image.get_rect()
        self.reset_position()

    def update(self, pala1, pala2, score, num_partida):
        self.rect.x += self.speed[0]
        self.rect.y += self.speed[1]

        # Colisión con los bordes superiores e inferiores de la pantalla
        if self.rect.top <= 0 or self.rect.bottom >= 480:  # El alto es fijo
            self.speed[1] = -self.speed[1]

    def reset_position(self):
        self.rect.x = self.ancho_pantalla // 2  # Posición central en la nueva pantalla de 960
        self.rect.y = 240
        # La velocidad inicial es aleatoria en X e Y
        self.speed = [random.choice([-3, 3]), random.choice([-3, 3])]

    def incrementar_velocidad(self, factor):
        self.speed[0] *= factor
        self.speed[1] *= factor
