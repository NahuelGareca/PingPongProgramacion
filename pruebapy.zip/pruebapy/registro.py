def registrar_colision(jugador, objeto, partida, coordenadas):
    with open('colisiones.txt', 'a') as file:
        file.write(f"Jugador: {jugador}, Objeto: {objeto}, Partida: {partida}, Coordenadas: {coordenadas}\n")
